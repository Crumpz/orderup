//
//  OrderUpChallengeApp.swift
//  OrderUpChallenge
//
//  Created by Sudowe, Yuki - Student on 9/6/24.
//

import SwiftUI

@main
struct OrderUpChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
