//
//  ContentView.swift
//  OrderUpChallenge
//
//  Created by Sudowe, Yuki - Student on 9/6/24.
//

import SwiftUI

struct ContentView: View {
    // Properties
    @State private var name: String = ""
    @State private var phoneNumber: String = ""
    @State private var address: String = ""
    @State private var paymentMethod: String = "Credit Card"
    @State private var promoCode: String = ""
    @State private var appliedPromoCode = false
    @State private var cart: [FoodItem] = []
    @State private var showPaymentPopup = false
    @State private var orderConfirmed = false
    
    // Tax and Delivery constants
    let taxRate = 0.0805
    let deliveryFeeRate = 0.10
    
    // Food items
    let foodItems: [FoodItem] = [
        FoodItem(title: "Pizza", price: 12.99, image: "🍕"),
        FoodItem(title: "Burger", price: 9.99, image: "🍔"),
        FoodItem(title: "Sushi", price: 14.99, image: "🍣"),
        FoodItem(title: "Pasta", price: 11.99, image: "🍝"),
        FoodItem(title: "Salad", price: 7.99, image: "🥗")
    ]
    
    // Computed properties
    var subtotal: Double {
        return cart.reduce(0) { $0 + $1.price }
    }
    
    var tax: Double {
        return subtotal * taxRate
    }
    
    var deliveryFee: Double {
        return address.isEmpty ? 0 : subtotal * deliveryFeeRate
    }
    
    var discount: Double {
        return appliedPromoCode ? subtotal * 0.25 : 0
    }
    
    var total: Double {
        return subtotal + tax + deliveryFee - discount
    }
    
    // Views
    var body: some View {
        NavigationView {
            VStack {
                // Food List
                List(foodItems) { food in
                    HStack {
                        Text(food.image)
                            .font(.largeTitle)
                        VStack(alignment: .leading) {
                            Text(food.title)
                                .font(.headline)
                            Text(String(format: "$%.2f", food.price))
                        }
                        Spacer()
                        Button(action: {
                            cart.append(food)
                        }) {
                            Text("Add to Cart")
                        }
                    }
                }
                
                // Cart summary and user info form
                VStack(alignment: .leading) {
                    Text("Cart: \(cart.count) items")
                        .font(.headline)
                    
                    if cart.count > 0 {
                        Text("Subtotal: \(String(format: "$%.2f", subtotal))")
                        Text("Tax: \(String(format: "$%.2f", tax))")
                        Text("Delivery Fee: \(String(format: "$%.2f", deliveryFee))")
                        Text("Discount: -\(String(format: "$%.2f", discount))")
                        Text("Total: \(String(format: "$%.2f", total))")
                    }
                    
                    TextField("Name", text: $name)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    TextField("Phone Number", text: $phoneNumber)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    TextField("Address (for delivery)", text: $address)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    TextField("Promo Code", text: $promoCode, onCommit: {
                        if promoCode == "myLuckyDay" {
                            appliedPromoCode = true
                                                        }
                    })
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .textInputAutocapitalization(.never)
                    Picker("Payment Method", selection: $paymentMethod) {
                        Text("Credit Card").tag("Credit Card")
                        Text("Apple Pay").tag("Apple Pay")
                        Text("Cash").tag("Cash")
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    
                    Button(action: {
                        showPaymentPopup = true
                    }) {
                        Text("Pay Now")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                    .padding()
                    .disabled(cart.isEmpty || name.isEmpty || phoneNumber.isEmpty)
                    .sheet(isPresented: $showPaymentPopup) {
                        VStack {
                            Text("Confirm Payment")
                                .font(.largeTitle)
                            Text("Name: \(name)")
                            Text("Phone: \(phoneNumber)")
                            Text("Payment Method: \(paymentMethod)")
                            Text("Total: \(String(format: "$%.2f", total))")
                            Button(action: {
                                orderConfirmed = true
                                showPaymentPopup = false
                            }) {
                                Text("Confirm Order")
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.green)
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                            }
                            .padding()
                        }
                        .padding()
                    }
                    
                    if orderConfirmed {
                        VStack(alignment: .leading) {
                            Text("Order Confirmed!")
                                .font(.largeTitle)
                                .padding(.bottom)
                            Text("Name: \(name)")
                            Text("Phone: \(phoneNumber)")
                            Text("Address: \(address)")
                            Text("Payment Method: \(paymentMethod)")
                            Text("Total: \(String(format: "$%.2f", total))")
                        }
                        .padding()
                    }
                }
                .padding()
            }
            .navigationTitle("Food Ordering App")
        }
    }
}

// FoodItem Model
struct FoodItem: Identifiable {
    var id = UUID()
    var title: String
    var price: Double
    var image: String
}

// Preview
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

